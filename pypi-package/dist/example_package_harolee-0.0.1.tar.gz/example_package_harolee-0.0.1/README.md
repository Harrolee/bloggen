# Bloggen

Point bloggen to a hosting location, give it your markdown, then watch it deploy a static site.
