import markdown;

def generate_html(input_md):
    html = markdown.markdown(input_md)
    return html

print (generate_html("# First Header"))